<html>
<head>
	<title>student data</title>
	<h1><center> Student report</center></h1>
	<base href="C:\xampp\htdocs\Hackathon\"/>
</head>
<body>
		<form  name="stddet" method="POST" action="stdata1.php">
		<table align="center" border="0">
		<tr>
			<td><br>STUDENTNAME:</td>
			<td><br><input type="username" name="t1" id="t1"/></td>
		</tr>
		<tr>
			<td><br>Regdno.</td>
			<td><br><input type="number" name="t2" id="t2"/></td>
		</tr>
		<tr>
			<td><br>Telugu</td>
			<td><br><input type="number" name="t3" id="t3"/></td>
		</tr>
		<tr>
			<td><br>Hindi</td>
			<td><br><input type="number" name="t4" id="t4"/></td>
		</tr>
		<tr>
			<td><br>English</td>
			<td><br><input type="number" name="t5" id="t5"/></td>
		</tr>
		<tr>
			<td><br>Mathematics</td>
			<td><br><input type="number" name="t6" id="t6"/></td>
		</tr>
		<tr>
			<td><br>Science</td>
			<td><br><input type="number" name="t7" id="t7"/></td>
		</tr>
		<tr>
			<td><br>social</td>
			<td><br><input type="number" name="t8" id="t8"/></td>
		</tr>
		<tr>
			<td><br>Total</td>
			<td><br><input type="number" name="t9" id="t9"/></td>
		</tr>
		<tr>
			<td><br>Submit</td>
			<td><br><input type="submit" name="submit"/></td>
		</tr>
		<tr>
		</tr>
	</form>
	<pre><a href="C:\xampp\htdocs\Hackathon\login.html"/>login</pre>
	<?php
		$usr="root";
		$pwd="";
		$admin=$_POST['adm'];
		$adminpwd=$_POST['adpwd'];
		if(($admin=="admin")&&($adminpwd=="adminpwd"))
		{
		echo "enter student marks";
		}
		else{
		echo "username or password incorrect";
		header('Location:home.html');
		#echo "<script>window.location.href='C:\xampp\htdocs\Hackathon\login.html';</script>";
		}
		if(isset($_POST["submit"])){
			$sname=$_POST['t1'];$regno=$_POST['t2'];$tel=$_POST['t3'];$hin=$_POST['t4'];$eng=$_POST['t5'];
			$mat=$_POST['t6'];$sci=$_POST['t7'];$sco=$_POST['t8'];
			$tot=$sci+$mat+$tel+$hin+$eng+$sco;
			$conn=mysqli_connect("localhost",$usr,$pwd,"student");
				if(!$conn){
				echo "connection failed";
				}
				else{
				echo "connection established";
				echo $sname;
				}
				#mysqli_select_db($conn,'student');
			$chk="INSERT INTO stumemo (`stuname`,`regdno`,`Telugu`,`Hindi`,`English`,`Mathematics`,`Science`,`Social`,`Total`)".
			"VALUES ('$sname','$regno','$tel','$hin','$eng','$mat','$sci','$sco','$tot')";
			$retval = mysqli_query($conn,$chk);
			if(!$retval){		
			die("query error".mysqli_error($conn));
			echo "not inserted";
			}
			else{
			echo "inserted";
			mysqli_close($conn);
			} 
		}
		?>
	</body>
</html>
		
		
		
		
		
